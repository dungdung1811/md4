create
    definer = dung@`%` procedure proc_insert_proc(IN P_name varchar(30), IN P_price float, IN qtt int, IN c_id int)
begin
    insert into Product11(Product_name,Price,quantity,categorys_id) value (P_name,P_price,qtt,c_id);
end;


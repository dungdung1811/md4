create
    definer = dung@`%` procedure pagination(IN sotrang_hientai int)
begin
    declare  batdau , gioihan_page int;
    set gioihan_page = 2;
    set batdau = (sotrang_hientai -1)* gioihan_page;
    select * from product11 limit gioihan_page offset batdau;

end;


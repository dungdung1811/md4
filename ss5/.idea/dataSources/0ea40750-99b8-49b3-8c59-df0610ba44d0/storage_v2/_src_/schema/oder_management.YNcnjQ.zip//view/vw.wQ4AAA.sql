create definer = dung@`%` view vw as
select `c`.`categorys_name` AS `categorys_name`, `p`.`Product_name` AS `Product_name`, `p`.`quantity` AS `quantity`
from (`oder_management`.`categorys` `c` join `oder_management`.`product11` `p`
      on ((`c`.`categorys_id` = `p`.`categorys_id`)))
group by `c`.`categorys_name`;


create
    definer = dung@`%` procedure update_product(IN p_id int, IN P_name varchar(30), IN P_price float, IN qtt int,
                                                IN c_id int)
begin
    update Product11
        set Product_name = P_name,
            Price = P_price,
            quantity = qtt,
            categorys_id = c_id
    where product_id = p_id  ;

end;


create
    definer = dung@`%` procedure delete_line(IN p_id int)
begin
    delete  from Product11
        where product_id = p_id;
end;


create definer = dung@`%` view vw as
select `s`.`TenSV` AS `TenSV`, `s`.`HocBong` AS `HocBong`
from (`studen_managemen1`.`dmsv` `s` join `studen_managemen1`.`dmkhoa` `k` on ((`s`.`Makhoa` = `k`.`Makhoa`)));

